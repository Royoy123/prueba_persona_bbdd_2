package org.example;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class RegistroInterfaz extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField emailField;

    public RegistroInterfaz() {
        setTitle("Registro");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en la pantalla

        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        emailField = new JTextField(20);

        JButton registerButton = new JButton("Registrar");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarRegistro();
            }
        });

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10)); // Añadido espacio entre componentes
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Añadido espacio alrededor del panel
        panel.add(new JLabel("Nombre de usuario:"));
        panel.add(usernameField);
        panel.add(new JLabel("Correo electrónico:"));
        panel.add(emailField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(passwordField);
        panel.add(new JLabel(""));
        panel.add(registerButton);

        add(panel);
    }

    private void realizarRegistro() {
        String username = usernameField.getText();
        String email = emailField.getText();
        char[] passwordChars = passwordField.getPassword();
        String password = new String(passwordChars);

        MongoDBConnection mongoDBConnection = MongoDBConnection.getInstance();
        MongoCollection<Document> userCollection = mongoDBConnection.getUserCollection();

        // Verificar si el usuario ya existe en la base de datos
        Document existingUser = userCollection.find(new Document("username", username)).first();
        if (existingUser != null) {
            JOptionPane.showMessageDialog(this, "Usuario ya registrado. Por favor, elige otro nombre de usuario.");
            return; // Detener el registro si el usuario ya existe
        }

        // Crear un nuevo documento con los datos del usuario
        Document newUser = new Document("username", username)
                .append("email", email)
                .append("password", password);

        // Insertar el nuevo usuario en la base de datos
        userCollection.insertOne(newUser);

        // Verificar si la inserción fue exitosa
        if (newUser.getObjectId("_id") != null) {
            // Registro exitoso, cerrar la ventana actual
            dispose();

            // Abrir la ventana de login
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new LoginInterfaz().setVisible(true);
                }
            });
        } else {
            // Hubo un problema al insertar en la base de datos
            JOptionPane.showMessageDialog(this, "Error al registrar usuario. Por favor, inténtalo de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Cerrar la conexión
        mongoDBConnection.closeConnection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RegistroInterfaz().setVisible(true);
            }
        });
    }
}
