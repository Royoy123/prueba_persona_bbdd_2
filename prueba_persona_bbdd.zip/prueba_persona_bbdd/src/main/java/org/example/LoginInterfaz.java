package org.example;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginInterfaz extends JFrame {
    private JTextField usernameOrEmailField;
    private JPasswordField passwordField;

    public LoginInterfaz() {
        setTitle("Login");
        setSize(400, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en la pantalla

        usernameOrEmailField = new JTextField(20);
        passwordField = new JPasswordField(20);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarLogin();
            }
        });

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10)); // Añadido espacio entre componentes
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Añadido espacio alrededor del panel
        panel.add(new JLabel("Nombre de usuario o Correo electrónico:"));
        panel.add(usernameOrEmailField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(passwordField);
        panel.add(new JLabel(""));
        panel.add(loginButton);

        add(panel);
    }

    private void realizarLogin() {
        String usernameOrEmail = usernameOrEmailField.getText();
        char[] passwordChars = passwordField.getPassword();
        String password = new String(passwordChars);

        MongoDBConnection mongoDBConnection = MongoDBConnection.getInstance();
        MongoCollection<Document> userCollection = mongoDBConnection.getUserCollection();

        // Verificar si el usuario y la contraseña existen en la base de datos
        Document query = new Document("$or",
                Arrays.asList(
                        new Document("username", usernameOrEmail).append("password", password),
                        new Document("email", usernameOrEmail).append("password", password)
                )
        );
        Document userDocument = userCollection.find(query).first();

        if (userDocument != null) {
            // Usuario autenticado correctamente
            JOptionPane.showMessageDialog(this, "Login exitoso");

            // Abrir la ventana de administración después del login exitoso
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new AdminInterfaz(usernameOrEmail).setVisible(true);
                }
            });

            // Cerrar la ventana actual de login
            dispose();
        } else {
            // Usuario no encontrado o contraseña incorrecta
            JOptionPane.showMessageDialog(this, "Error de login. Verifica tus credenciales.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        mongoDBConnection.closeConnection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginInterfaz().setVisible(true);
            }
        });
    }
}
